# lab_instructions.txt

In the text will you will find the hw instructions

ヽ(๏∀๏ )ﾉ





## ← intro.html

pretty much the index.html 

