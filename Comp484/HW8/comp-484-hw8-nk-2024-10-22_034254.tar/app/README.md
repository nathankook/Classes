# My resume website

This file describes your project to the community. What's your cool website about? What makes it special?

ヽ(๏∀๏ )ﾉ

## ← index.html

Where you'll write the content of your website. 

## ← styles.css

CSS files add styling rules to your content
