Elements:

figcaption used to explain/describe images 
  - roles.html
  - esports.html
  
table used to create a table of the agents and their respective roles
  - agents.html
  
caption used to explain what information is in the table
  - agents.html
  
Atrributes:

draggable used to drag agent profiles and table
  - agents.html

accesskey used to assign keys that can be pressed to navigate to specific sections
  - all pages' links have accesskeys (1,2,3,4 for navigating through the pages)
  
itemprop used to add properties to the roles and agents
  - roles.html
  - agents.html
  
dir was difficult to use, since default value is ltr(left to right); i understand that it should be used with other languages that read right to left
  - agents.html (just assigned it ltr even though that is the default)

